import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';

import { SignupFormComponent } from './signup-form.component';

@NgModule({
  imports:      [ BrowserModule, ReactiveFormsModule ],
  declarations: [SignupFormComponent ],
  bootstrap:    [ SignupFormComponent ]
})
export class AppModule { }
